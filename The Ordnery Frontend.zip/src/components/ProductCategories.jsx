
// frontend/src/components/ProductCategories.jsx
import React from 'react';

const ProductCategories = () => {
  const categories = [
    { name: "SUNSCREEN", link: "#" },
    { name: "SET & DEALS", link: "#" },
    { name: "FOUNDATION", link: "#" },
    { name: "HAIR", link: "#" },
    { name: "TONERS", link: "#" },
    // Add more categories as needed
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold">The Ordinary Product Categories</h2>
        <button className="bg-gray-900 text-white px-6 py-2 rounded-full text-md font-semibold hover:bg-gray-700 transition duration-300 ease-in-out flex items-center">
          Explore All
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.25 8.25L21 12m0 0l-3.75 3.75M21 12H3" />
          </svg>
        </button>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 text-center">
        {categories.map((category) => (
          <a
            key={category.name}
            href={category.link}
            className="block p-4 rounded-lg bg-gray-50 hover:bg-gray-100 transition duration-300 ease-in-out text-lg font-medium text-gray-700 hover:text-gray-900"
          >
            {category.name}
          </a>
        ))}
      </div>
    </div>
  );
};

export default ProductCategories;
