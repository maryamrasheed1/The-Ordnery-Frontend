// frontend/src/components/ProductGrid.jsx
import React from 'react';
import ProductCard from './ProductCard'; // Import the ProductCard component
import './ProductGrid.css'; // Import dedicated CSS for the grid layout

const ProductGrid = ({ type = "products" }) => { // Added type prop for potential reuse
  // This would typically come from an API call in a real application
  const products = [
    {
      id: 1,
      name: "Niacinamide 10% + Zinc 1%",
      brand: "The Ordinary",
      image: "https://placehold.co/300x300/F0F0F0/888888?text=Product+1",
      rating: 4,
      reviews: 91,
      oldPrice: 5768,
      price: 2680,
      discount: "-53%",
      isHot: true,
    },
    {
      id: 2,
      name: "Hyaluronic Acid 2% + B5 (with Ceramides)",
      brand: "The Ordinary",
      image: "https://placehold.co/300x300/F0F0F0/888888?text=Product+2",
      rating: 4,
      reviews: 26,
      oldPrice: 4400,
      price: 2680,
      discount: "-40%",
      isHot: true,
    },
    {
      id: 3,
      name: "AHA 30% + BHA 2% Peeling Solution",
      brand: "The Ordinary",
      image: "https://placehold.co/300x300/F0F0F0/888888?text=Product+3",
      rating: 4,
      reviews: 13,
      oldPrice: 4200,
      price: 2685,
      discount: "-36%",
      isHot: false,
    },
    {
      id: 4,
      name: "Salicylic Acid 2% Solution",
      brand: "The Ordinary",
      image: "https://placehold.co/300x300/F0F0F0/888888?text=Product+4",
      rating: 4,
      reviews: 11,
      oldPrice: 6500,
      price: 2850,
      discount: "-57%",
      isHot: false,
    },
    {
      id: 5,
      name: "Retinol Serum 0.2% in Squalane",
      brand: "The Ordinary",
      image: "https://placehold.co/300x300/F0F0F0/888888?text=Product+5",
      rating: 4,
      reviews: 4,
      oldPrice: 6500,
      price: 2980,
      discount: "-55%",
      isHot: false,
    },
    // Additional products for the "deals" section if type is "deals"
    ...(type === "deals" ? [
      {
        id: 6,
        name: "Alpha Arbutin 2% HA + Caffeine Solution 5% EGCG Combo",
        brand: "The Ordinary",
        image: "https://placehold.co/300x300/F0F0F0/888888?text=Deal+Image+1",
        rating: 4,
        reviews: 15,
        oldPrice: 3500,
        price: 2940,
        discount: "-16%",
        isHot: false,
      },
      {
        id: 7,
        name: "Hyaluronic Acid 2% B5 + Caffeine Solution 5% EGCG Combo",
        brand: "The Ordinary",
        image: "https://placehold.co/300x300/F0F0F0/888888?text=Deal+Image+2",
        rating: 4,
        reviews: 20,
        oldPrice: 4000,
        price: 2960,
        discount: "-26%",
        isHot: false,
      },
      {
        id: 8,
        name: "The Most Loved Collection",
        brand: "The Ordinary",
        image: "https://placehold.co/300x300/F0F0F0/888888?text=Deal+Image+3",
        rating: 5,
        reviews: 30,
        oldPrice: 7000,
        price: 5740,
        discount: "-18%",
        isHot: false,
      },
      {
        id: 9,
        name: "Hair & Scalp Collection",
        brand: "The Ordinary",
        image: "https://placehold.co/300x300/F0F0F0/888888?text=Deal+Image+4",
        rating: 4,
        reviews: 10,
        oldPrice: 6000,
        price: 4020,
        discount: "-33%",
        isHot: false,
      },
      {
        id: 10,
        name: "The Daily Set",
        brand: "The Ordinary",
        image: "https://placehold.co/300x300/F0F0F0/888888?text=Deal+Image+5",
        rating: 4,
        reviews: 8,
        oldPrice: 5000,
        price: 4550,
        discount: "-9%",
        isHot: false,
      },
    ] : [])
  ];

  return (
    <section className="product-grid-section">
      <h2 className="grid-section-title">Our Top Products</h2>
      <div className="product-grid-container">
        {/* Render products based on the 'type' prop */}
        {products.filter(p => type === "deals" ? p.id >= 6 : p.id < 6).map((product) => (
          <ProductCard key={product.id} item={product} />
        ))}
      </div>
    </section>
  );
};

export default ProductGrid;
