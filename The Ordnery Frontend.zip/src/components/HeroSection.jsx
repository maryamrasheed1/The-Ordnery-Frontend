// frontend/src/components/HeroSection.jsx
import React from 'react';

const HeroSection = () => {
  return (
    <section className="hero-section">
      <div className="video-background">
        <video
          className="video-element"
          autoPlay
          loop
          muted
          playsInline
        >
          <source src="/hero-video.mp4" type="video/mp4" /> {/* Assumes video in public folder */}
          Your browser does not support the video tag.
        </video>
        <div className="video-overlay"></div>
      </div>

      {/* Foreground Content */}
      <div className="hero-content-wrapper">
        {/* Sidebar */}
        <div className="reviews-sidebar">
          <span className="reviews-text">★ Reviews</span>
        </div>

        {/* Content Card */}
        <div className="content-card">
          <h1 className="card-title">Original The Ordinary Pakistan</h1>
          <p className="card-subtitle">Official Store in Pakistan</p>
          <p className="card-description">
            Experience the transformative power of Authentic The Ordinary products
            in Pakistan, which we designed to give your skin the flawless appearance
            you've always desired. With our extensive range of clinical formulations
            with integrity ensures, you can peacefully achieve your skincare goals
            effectively. Shop now and discover the difference that original The
            Ordinary products can make in your daily routine.
          </p>
          <p className="card-note">
            (We do not deal through any other website or Facebook/Instagram page.)
          </p>
          <button className="shop-now-button">Shop Now →</button>
        </div>
      </div>

      {/* WhatsApp Chat Button - Often a global element, but included here as per your previous code */}
      <button className="whatsapp-button" aria-label="Chat on WhatsApp">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 16 16" fill="currentColor">
          <path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.542.063 7.918c0 1.454.39 2.87.937 4.13L.002 16l4.207-1.102a7.925 7.925 0 0 0 3.79.965h.004c4.368 0 7.92-3.542 7.92-7.917-.001-2.344-.954-4.507-2.695-6.148zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.543c0-3.661 2.969-6.63 6.633-6.63 1.813 0 3.51.745 4.787 2.07.759.752 1.257 1.745 1.405 2.808.083.653.05 1.317-.024 1.979-.092.709-.256 1.405-.487 2.06-.329.932-.782 1.77-1.374 2.493-.665.827-1.503 1.474-2.474 1.916a6.56 6.56 0 0 1-3.53-.92zM10.749 9.53a.5.5 0 0 0-.74-.063l-2.237-2.237a.5.5 0 0 0-.707 0L6.05 7.373a.5.5 0 0 0 .707.707L8 6.707l1.72 1.72a.5.5 0 0 0 .707 0l.707-.707a.5.5 0 0 0 0-.707z"/>
        </svg>
      </button>
    </section>
  );
};

export default HeroSection;
