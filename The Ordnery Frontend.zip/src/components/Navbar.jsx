// frontend/src/components/Navbar.jsx
import React from 'react';
import './Navbar.css'; // Import Navbar specific CSS

const Navbar = () => {
  const navItems = [
    "NEW", "BESTSELLER", "SKINCARE", "HAIR+BODY", "SETS & COLLECTIONS", "TRACK ORDER", "REGIMEN"
  ];
  return (
    <nav className="nav-links-bar">
      <ul className="nav-list">
        {navItems.map((item) => (
          <li key={item}>
            <a href="#">{item}</a>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Navbar;
